﻿namespace ActivitatMVC1._1.View
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.bUpd = new System.Windows.Forms.Button();
            this.bIns = new System.Windows.Forms.Button();
            this.bDAll = new System.Windows.Forms.Button();
            this.bDel = new System.Windows.Forms.Button();
            this.Books = new System.Windows.Forms.Label();
            this.Autor = new System.Windows.Forms.Label();
            this.dgvBooks = new System.Windows.Forms.DataGridView();
            this.Autors = new System.Windows.Forms.Label();
            this.tbAuthor = new System.Windows.Forms.TextBox();
            this.dgvAuthors = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.tBFiltre = new System.Windows.Forms.TextBox();
            this.chBActiu = new System.Windows.Forms.CheckBox();
            this.chbActiuBooks = new System.Windows.Forms.CheckBox();
            this.tbFiltreBooks = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dgvBooksBooks = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.cbAutorsBooks = new System.Windows.Forms.ComboBox();
            this.bDelBooks = new System.Windows.Forms.Button();
            this.bUpdBooks = new System.Windows.Forms.Button();
            this.bInsBooks = new System.Windows.Forms.Button();
            this.tBTitleBooks = new System.Windows.Forms.TextBox();
            this.tBDescriptionBooks = new System.Windows.Forms.TextBox();
            this.tBPriceBooks = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuthors)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooksBooks)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(2, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(705, 364);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(725, 345);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Query";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(422, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Preu";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(274, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Descripcio";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(274, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Llibres de L\'autor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Autors";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(248, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 14;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(425, 161);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(277, 161);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 12;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(277, 76);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 11;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(69, 79);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 10;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chBActiu);
            this.tabPage2.Controls.Add(this.tBFiltre);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.bUpd);
            this.tabPage2.Controls.Add(this.bIns);
            this.tabPage2.Controls.Add(this.bDAll);
            this.tabPage2.Controls.Add(this.bDel);
            this.tabPage2.Controls.Add(this.Books);
            this.tabPage2.Controls.Add(this.Autor);
            this.tabPage2.Controls.Add(this.dgvBooks);
            this.tabPage2.Controls.Add(this.Autors);
            this.tabPage2.Controls.Add(this.tbAuthor);
            this.tabPage2.Controls.Add(this.dgvAuthors);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(697, 338);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Authors";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // bUpd
            // 
            this.bUpd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bUpd.Location = new System.Drawing.Point(249, 223);
            this.bUpd.Name = "bUpd";
            this.bUpd.Size = new System.Drawing.Size(75, 23);
            this.bUpd.TabIndex = 9;
            this.bUpd.Text = "UPD";
            this.bUpd.UseVisualStyleBackColor = true;
            // 
            // bIns
            // 
            this.bIns.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.bIns.Location = new System.Drawing.Point(151, 222);
            this.bIns.Name = "bIns";
            this.bIns.Size = new System.Drawing.Size(75, 23);
            this.bIns.TabIndex = 8;
            this.bIns.Text = "INS";
            this.bIns.UseVisualStyleBackColor = true;
            // 
            // bDAll
            // 
            this.bDAll.Location = new System.Drawing.Point(258, 138);
            this.bDAll.Name = "bDAll";
            this.bDAll.Size = new System.Drawing.Size(75, 23);
            this.bDAll.TabIndex = 7;
            this.bDAll.Text = "DEL ALL";
            this.bDAll.UseVisualStyleBackColor = true;
            // 
            // bDel
            // 
            this.bDel.Location = new System.Drawing.Point(258, 98);
            this.bDel.Name = "bDel";
            this.bDel.Size = new System.Drawing.Size(75, 23);
            this.bDel.TabIndex = 6;
            this.bDel.Text = "DEL";
            this.bDel.UseVisualStyleBackColor = true;
            // 
            // Books
            // 
            this.Books.AutoSize = true;
            this.Books.Location = new System.Drawing.Point(393, 45);
            this.Books.Name = "Books";
            this.Books.Size = new System.Drawing.Size(37, 13);
            this.Books.TabIndex = 5;
            this.Books.Text = "Books";
            // 
            // Autor
            // 
            this.Autor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Autor.AutoSize = true;
            this.Autor.Location = new System.Drawing.Point(20, 209);
            this.Autor.Name = "Autor";
            this.Autor.Size = new System.Drawing.Size(32, 13);
            this.Autor.TabIndex = 4;
            this.Autor.Text = "Autor";
            // 
            // dgvBooks
            // 
            this.dgvBooks.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBooks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvBooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBooks.Location = new System.Drawing.Point(396, 61);
            this.dgvBooks.MultiSelect = false;
            this.dgvBooks.Name = "dgvBooks";
            this.dgvBooks.ReadOnly = true;
            this.dgvBooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBooks.Size = new System.Drawing.Size(149, 110);
            this.dgvBooks.TabIndex = 3;
            // 
            // Autors
            // 
            this.Autors.AutoSize = true;
            this.Autors.Location = new System.Drawing.Point(20, 45);
            this.Autors.Name = "Autors";
            this.Autors.Size = new System.Drawing.Size(37, 13);
            this.Autors.TabIndex = 2;
            this.Autors.Text = "Autors";
            // 
            // tbAuthor
            // 
            this.tbAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbAuthor.Location = new System.Drawing.Point(23, 225);
            this.tbAuthor.Name = "tbAuthor";
            this.tbAuthor.Size = new System.Drawing.Size(100, 20);
            this.tbAuthor.TabIndex = 1;
            // 
            // dgvAuthors
            // 
            this.dgvAuthors.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvAuthors.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvAuthors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAuthors.Location = new System.Drawing.Point(23, 61);
            this.dgvAuthors.MultiSelect = false;
            this.dgvAuthors.Name = "dgvAuthors";
            this.dgvAuthors.ReadOnly = true;
            this.dgvAuthors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAuthors.Size = new System.Drawing.Size(177, 110);
            this.dgvAuthors.TabIndex = 0;
            this.dgvAuthors.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAuthors_CellContentClick);
            this.dgvAuthors.SelectionChanged += new System.EventHandler(this.dgvAuthors_SelectionChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.tBPriceBooks);
            this.tabPage3.Controls.Add(this.tBDescriptionBooks);
            this.tabPage3.Controls.Add(this.tBTitleBooks);
            this.tabPage3.Controls.Add(this.bInsBooks);
            this.tabPage3.Controls.Add(this.bUpdBooks);
            this.tabPage3.Controls.Add(this.bDelBooks);
            this.tabPage3.Controls.Add(this.cbAutorsBooks);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.dgvBooksBooks);
            this.tabPage3.Controls.Add(this.chbActiuBooks);
            this.tabPage3.Controls.Add(this.tbFiltreBooks);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(697, 338);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Books";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Filtre";
            // 
            // tBFiltre
            // 
            this.tBFiltre.Location = new System.Drawing.Point(58, 9);
            this.tBFiltre.Name = "tBFiltre";
            this.tBFiltre.Size = new System.Drawing.Size(100, 20);
            this.tBFiltre.TabIndex = 11;
            // 
            // chBActiu
            // 
            this.chBActiu.AutoSize = true;
            this.chBActiu.Location = new System.Drawing.Point(174, 12);
            this.chBActiu.Name = "chBActiu";
            this.chBActiu.Size = new System.Drawing.Size(50, 17);
            this.chBActiu.TabIndex = 12;
            this.chBActiu.Text = "Actiu";
            this.chBActiu.UseVisualStyleBackColor = true;
            // 
            // chbActiuBooks
            // 
            this.chbActiuBooks.AutoSize = true;
            this.chbActiuBooks.Location = new System.Drawing.Point(160, 18);
            this.chbActiuBooks.Name = "chbActiuBooks";
            this.chbActiuBooks.Size = new System.Drawing.Size(50, 17);
            this.chbActiuBooks.TabIndex = 15;
            this.chbActiuBooks.Text = "Actiu";
            this.chbActiuBooks.UseVisualStyleBackColor = true;
            // 
            // tbFiltreBooks
            // 
            this.tbFiltreBooks.Location = new System.Drawing.Point(44, 15);
            this.tbFiltreBooks.Name = "tbFiltreBooks";
            this.tbFiltreBooks.Size = new System.Drawing.Size(100, 20);
            this.tbFiltreBooks.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Filtre";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Books";
            // 
            // dgvBooksBooks
            // 
            this.dgvBooksBooks.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBooksBooks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvBooksBooks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBooksBooks.Location = new System.Drawing.Point(11, 72);
            this.dgvBooksBooks.MultiSelect = false;
            this.dgvBooksBooks.Name = "dgvBooksBooks";
            this.dgvBooksBooks.ReadOnly = true;
            this.dgvBooksBooks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBooksBooks.Size = new System.Drawing.Size(400, 197);
            this.dgvBooksBooks.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(496, 56);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Author";
            // 
            // cbAutorsBooks
            // 
            this.cbAutorsBooks.FormattingEnabled = true;
            this.cbAutorsBooks.Location = new System.Drawing.Point(499, 72);
            this.cbAutorsBooks.Name = "cbAutorsBooks";
            this.cbAutorsBooks.Size = new System.Drawing.Size(121, 21);
            this.cbAutorsBooks.TabIndex = 19;
            // 
            // bDelBooks
            // 
            this.bDelBooks.Location = new System.Drawing.Point(485, 246);
            this.bDelBooks.Name = "bDelBooks";
            this.bDelBooks.Size = new System.Drawing.Size(75, 23);
            this.bDelBooks.TabIndex = 20;
            this.bDelBooks.Text = "DEL";
            this.bDelBooks.UseVisualStyleBackColor = true;
            // 
            // bUpdBooks
            // 
            this.bUpdBooks.Location = new System.Drawing.Point(599, 246);
            this.bUpdBooks.Name = "bUpdBooks";
            this.bUpdBooks.Size = new System.Drawing.Size(75, 23);
            this.bUpdBooks.TabIndex = 21;
            this.bUpdBooks.Text = "UPD";
            this.bUpdBooks.UseVisualStyleBackColor = true;
            // 
            // bInsBooks
            // 
            this.bInsBooks.Location = new System.Drawing.Point(599, 292);
            this.bInsBooks.Name = "bInsBooks";
            this.bInsBooks.Size = new System.Drawing.Size(75, 23);
            this.bInsBooks.TabIndex = 22;
            this.bInsBooks.Text = "INS";
            this.bInsBooks.UseVisualStyleBackColor = true;
            // 
            // tBTitleBooks
            // 
            this.tBTitleBooks.Location = new System.Drawing.Point(11, 295);
            this.tBTitleBooks.Name = "tBTitleBooks";
            this.tBTitleBooks.Size = new System.Drawing.Size(119, 20);
            this.tBTitleBooks.TabIndex = 23;
            // 
            // tBDescriptionBooks
            // 
            this.tBDescriptionBooks.Location = new System.Drawing.Point(150, 295);
            this.tBDescriptionBooks.Name = "tBDescriptionBooks";
            this.tBDescriptionBooks.Size = new System.Drawing.Size(307, 20);
            this.tBDescriptionBooks.TabIndex = 24;
            // 
            // tBPriceBooks
            // 
            this.tBPriceBooks.Location = new System.Drawing.Point(477, 295);
            this.tBPriceBooks.Name = "tBPriceBooks";
            this.tBPriceBooks.Size = new System.Drawing.Size(100, 20);
            this.tBPriceBooks.TabIndex = 25;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 279);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "Title";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(147, 279);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "Description";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(474, 279);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Price";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 363);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAuthors)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooksBooks)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.ComboBox comboBox2;
        public System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TabPage tabPage2;
        public System.Windows.Forms.DataGridView dgvAuthors;
        public System.Windows.Forms.TextBox tbAuthor;
        public System.Windows.Forms.Button bUpd;
        public System.Windows.Forms.Button bIns;
        public System.Windows.Forms.Button bDAll;
        public System.Windows.Forms.Button bDel;
        private System.Windows.Forms.Label Books;
        private System.Windows.Forms.Label Autor;
        public System.Windows.Forms.DataGridView dgvBooks;
        private System.Windows.Forms.Label Autors;
        public System.Windows.Forms.CheckBox chBActiu;
        public System.Windows.Forms.TextBox tBFiltre;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox tBPriceBooks;
        public System.Windows.Forms.TextBox tBDescriptionBooks;
        public System.Windows.Forms.TextBox tBTitleBooks;
        public System.Windows.Forms.Button bInsBooks;
        public System.Windows.Forms.Button bUpdBooks;
        public System.Windows.Forms.Button bDelBooks;
        public System.Windows.Forms.ComboBox cbAutorsBooks;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.DataGridView dgvBooksBooks;
        public System.Windows.Forms.CheckBox chbActiuBooks;
        public System.Windows.Forms.TextBox tbFiltreBooks;
        private System.Windows.Forms.Label label8;
    }
}

